<!-- META -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- META -->
<!-- CSS -->
<link href="./assets/bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
<link href="./assets/DataTables/datatables.min.css" rel="stylesheet" media="screen">
<link href="./assets/fontawesome-free/css/all.css" rel="stylesheet" media="screen">
<link href="./assets/bootstrap-notify/animate.css" rel="stylesheet" media="screen">
<link href="./assets/multiple-select/fSelect.css" rel="stylesheet" media="screen">
<!-- CSS -->