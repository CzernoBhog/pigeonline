<script src="./assets/bootstrap/jquery-3.3.1.min.js"></script>
<script src="./assets/DataTables/datatables.min.js"></script>
<script src="./assets/bootstrap/js/bootstrap.min.js"></script>
<script src="./assets/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="./assets/redirect.js"></script>
<script src="./assets/multiple-select/fSelect.js"></script>