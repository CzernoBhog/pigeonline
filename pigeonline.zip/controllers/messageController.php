<?php

namespace controllers;

require_once('utils/autoload.php');

class messageController
{
    
}
